# jquery_ui_multiselect_widget
Drupal 8 Port of https://www.drupal.org/project/jquery_ui_multiselect_widget
